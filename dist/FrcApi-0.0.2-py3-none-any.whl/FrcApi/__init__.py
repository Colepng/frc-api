from .config import token

from .rankings import Rankings